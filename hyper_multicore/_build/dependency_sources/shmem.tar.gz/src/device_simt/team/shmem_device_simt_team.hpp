/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */
#ifndef SHMEM_DEVICE_SIMT_TEAM_HPP
#define SHMEM_DEVICE_SIMT_TEAM_HPP

#include "host_device/shmem_common_types.h"
#include "device_simt/shmem_simt_common_types.h"
#include "utils/shmemi_simt_kernel_debug.h"

namespace simt {

__simt_callee__ inline void aclshmemi_check_team_pe(int pe, int team_size)
{
    if (pe < 0 || pe >= team_size) {
        simt::aclshmemi_kernel_abort("invalid PE index: pe=%d, team_size=%d\n", pe, team_size);
    }
}

__simt_callee__ inline int aclshmem_my_pe(void)
{
    __gm__ aclshmem_device_host_state_simt_t* device_state = simt::aclshmemi_get_state();
    __gm__ aclshmemx_team_t* team_ptr = (__gm__ aclshmemx_team_t*)device_state->team_pools[ACLSHMEM_TEAM_WORLD];
    return team_ptr->mype;
}

__simt_callee__ inline int aclshmem_n_pes(void)
{
    __gm__ aclshmem_device_host_state_simt_t* device_state = simt::aclshmemi_get_state();
    __gm__ aclshmemx_team_t* team_ptr = (__gm__ aclshmemx_team_t*)device_state->team_pools[ACLSHMEM_TEAM_WORLD];
    return team_ptr->size;
}

__simt_callee__ inline int aclshmem_team_my_pe(aclshmem_team_t team)
{
    if (team == ACLSHMEM_TEAM_INVALID) {
        return -1;
    } else {
        __gm__ aclshmemx_team_t* src_team_ptr = (__gm__ aclshmemx_team_t*)aclshmemi_get_state()->team_pools[team];
        return (src_team_ptr != nullptr ? src_team_ptr->mype : -1);
    }
}

__simt_callee__ inline int aclshmem_team_n_pes(aclshmem_team_t team)
{
    if (team == ACLSHMEM_TEAM_INVALID) {
        return -1;
    } else {
        __gm__ aclshmemx_team_t* src_team_ptr = (__gm__ aclshmemx_team_t*)aclshmemi_get_state()->team_pools[team];
        return (src_team_ptr != nullptr ? src_team_ptr->size : -1);
    }
}

__simt_callee__ inline int aclshmem_team_translate_pe(aclshmem_team_t src_team, int src_pe, aclshmem_team_t dest_team)
{
    if (src_team == ACLSHMEM_TEAM_INVALID || dest_team == ACLSHMEM_TEAM_INVALID) {
        return -1;
    }
    __gm__ aclshmem_device_host_state_simt_t* device_state = aclshmemi_get_state();

    __gm__ aclshmemx_team_t* src_team_ptr = (__gm__ aclshmemx_team_t*)device_state->team_pools[src_team];
    __gm__ aclshmemx_team_t* dest_team_ptr = (__gm__ aclshmemx_team_t*)device_state->team_pools[dest_team];

    ACLSHMEM_DEBUG_FUNC(simt::aclshmemi_check_team_pe, src_pe, src_team_ptr->size);

    int global_pe = src_team_ptr->pe_mapping[src_pe];
    return dest_team_ptr->pe_mapping[global_pe + ACLSHMEM_MAX_PES];
}

__simt_callee__ inline int aclshmem_team_pe_mapping(aclshmem_team_t team, int pe)
{
    if (team == ACLSHMEM_TEAM_INVALID) {
        return -1;
    }
    __gm__ aclshmem_device_host_state_simt_t* device_state = aclshmemi_get_state();
    __gm__ aclshmemx_team_t* team_ptr = (__gm__ aclshmemx_team_t*)device_state->team_pools[team];

    ACLSHMEM_DEBUG_FUNC(simt::aclshmemi_check_team_pe, pe, team_ptr->size);

    return team_ptr->pe_mapping[pe];
}

} // namespace simt

#endif
