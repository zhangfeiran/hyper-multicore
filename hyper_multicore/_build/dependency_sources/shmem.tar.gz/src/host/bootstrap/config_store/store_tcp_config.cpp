/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include "store_tcp_config.h"
#include <chrono>
#include "host/shmem_host_def.h"
#include "shmemi_logger.h"
#include "store_message_packer.h"
#include "store_net_common.h"

namespace shm {
namespace store {
// Connection retry max times: with usleep(1ms) per retry, 20000 retries ≈ 20s total patience.
constexpr auto CONNECT_RETRY_MAX_TIMES = 20000;

class ClientWaitContext : public ClientCommonContext {
public:
    explicit ClientWaitContext(int64_t timeoutMs = kDefaultSendMsgTimeoutMs) noexcept
        : finished_{false},
          timeoutMs_{timeoutMs}
    {
    }

    std::shared_ptr<shm::acc::AccTcpRequestContext> WaitFinished() noexcept override
    {
        std::unique_lock<std::mutex> locker{waitMutex_};
        if (timeoutMs_ > 0) {
            if (!waitCond_.wait_for(locker, std::chrono::milliseconds(timeoutMs_), [this]() { return finished_; })) {
                SHM_LOG_ERROR("WaitFinished timeout after " << timeoutMs_ << "ms, link may be broken");
                responseInfo_ = nullptr;
                finished_ = true;
            }
        } else {
            waitCond_.wait(locker, [this]() { return finished_; });
        }
        auto copy = responseInfo_;
        locker.unlock();

        return copy;
    }

    void SetFinished(const shm::acc::AccTcpRequestContext &response) noexcept override
    {
        std::unique_lock<std::mutex> locker{waitMutex_};
        responseInfo_ = std::make_shared<shm::acc::AccTcpRequestContext>(response);
        finished_ = true;
        locker.unlock();

        waitCond_.notify_one();
    }

    void SetFailedFinish() noexcept override
    {
        std::unique_lock<std::mutex> locker{waitMutex_};
        finished_ = true;
        responseInfo_ = nullptr;
        locker.unlock();

        waitCond_.notify_one();
    }
    bool Blocking() const noexcept override
    {
        return true;
    }

private:
    std::mutex waitMutex_;
    std::condition_variable waitCond_;
    bool finished_;
    int64_t timeoutMs_;
    std::shared_ptr<shm::acc::AccTcpRequestContext> responseInfo_;
};

class ClientWatchContext : public ClientCommonContext {
public:
    explicit ClientWatchContext(std::function<void(int result, const std::vector<uint8_t> &)> nfy) noexcept
        : notify_{std::move(nfy)}
    {
    }

    std::shared_ptr<shm::acc::AccTcpRequestContext> WaitFinished() noexcept override
    {
        return nullptr;
    }

    void SetFinished(const shm::acc::AccTcpRequestContext &response) noexcept override
    {
        auto data = reinterpret_cast<const uint8_t *>(response.DataPtr());

        SmemMessage responseBody;
        auto ret = SmemMessagePacker::Unpack(data, response.DataLen(), responseBody);
        if (ret < 0) {
            SHM_LOG_ERROR("unpack response body failed, result: " << ret);
            notify_(IO_ERROR, std::vector<uint8_t>{});
            return;
        }

        if (responseBody.values.empty()) {
            SHM_LOG_ERROR("response body has no value");
            notify_(IO_ERROR, std::vector<uint8_t>{});
            return;
        }

        SHM_LOG_DEBUG("watch end, id: " << response.SeqNo());
        notify_(SUCCESS, responseBody.values[0]);
    }

    void SetFailedFinish() noexcept override
    {
        notify_(IO_ERROR, std::vector<uint8_t>{});
    }

    bool Blocking() const noexcept override
    {
        return false;
    }

private:
    std::function<void(int result, const std::vector<uint8_t> &)> notify_;
};

std::atomic<uint32_t> TcpConfigStore::reqSeqGen_{0};
TcpConfigStore::TcpConfigStore(std::string ip, uint16_t port, bool isServer, int32_t rankId, int32_t sockFd,
                               uint16_t magic) noexcept
    : serverIp_{std::move(ip)},
      serverPort_{port},
      isServer_{isServer},
      rankId_{rankId},
      sockFd_{sockFd},
      magic_{magic}
{
}

TcpConfigStore::~TcpConfigStore() noexcept
{
    Shutdown();
}

Result TcpConfigStore::AccClientStart(const AcclinkTlsOption &tlsOption) noexcept
{
    shm::acc::AccTcpServerOptions options;
    options.linkSendQueueSize = shm::acc::UNO_48;

    shm::acc::AccTlsOption tlsOpt = ConvertTlsOption(tlsOption);
    Result result;
    if (tlsOpt.enableTls) {
        if (tlsOption.decryptHandler_ != nullptr) {
            accClient_->RegisterDecryptHandler(tlsOption.decryptHandler_);
        }
        result = accClient_->Start(options, tlsOpt);
    } else {
        result = accClient_->Start(options);
    }
    return result;
}

Result TcpConfigStore::Startup(const AcclinkTlsOption &tlsOption, int reconnectRetryTimes) noexcept
{
    Result result = SM_OK;
    auto retryMaxTimes = reconnectRetryTimes < 0 ? CONNECT_RETRY_MAX_TIMES : reconnectRetryTimes;

    std::lock_guard<std::mutex> guard(mutex_);
    if (accClient_ != nullptr) {
        SHM_LOG_INFO("TcpConfigStore already startup");
        return SM_OK;
    }

    accClient_ = shm::acc::AccTcpServer::Create();
    if (accClient_ == nullptr) {
        SHM_LOG_ERROR("create acc tcp client failed");
        return SM_ERROR;
    }

    if (tlsOption.enableTls) {
        result = accClient_->LoadDynamicLib(tlsOption.packagePath);
    }

    if (isServer_) {
        SHM_LOG_INFO("Rank " << rankId_ << " starting as SERVER on " << serverIp_ << ":" << serverPort_
            << " magic=" << magic_);
        accServer_ = SmMakeRef<AccStoreServer>(serverIp_, serverPort_, sockFd_, magic_);
        if (accServer_ == nullptr) {
            SHM_LOG_ERROR("Failed to create AccStoreServer instance");
            Shutdown();
            sockFd_ = -1;
            return SM_NEW_OBJECT_FAILED;
        }

        if ((result = accServer_->Startup(tlsOption)) != SM_OK) {
            SHM_LOG_ERROR("AccStoreServer startup failed: " << result);
            Shutdown();
            sockFd_ = -1;
            return result;
        }
    }

    accClient_->RegisterNewRequestHandler(
        0, [this](const shm::acc::AccTcpRequestContext &context) { return ReceiveResponseHandler(context); });
    accClient_->RegisterLinkBrokenHandler(
        [this](const shm::acc::AccTcpLinkComplexPtr &link) { return LinkBrokenHandler(link); });

    if ((result = AccClientStart(tlsOption)) != SM_OK) {
        SHM_LOG_ERROR("start acc client failed, result: " << result);
        Shutdown();
        return result;
    }

    shm::acc::AccConnReq connReq;
    connReq.rankId = rankId_;
    connReq.magic = magic_;
    SHM_LOG_INFO("Rank " << rankId_ << " connecting as CLIENT to " << serverIp_ << ":" << serverPort_
        << " magic=" << magic_);
    result = accClient_->ConnectToPeerServer(serverIp_, serverPort_, connReq, retryMaxTimes, accClientLink_);
    if (result != 0) {
        SHM_LOG_ERROR("connect to server failed, result: " << result);
        Shutdown();
        return result;
    }

    return SM_OK;
}

void TcpConfigStore::Shutdown(bool afterFork) noexcept
{
    accClientLink_ = nullptr;

    if (accClient_ != nullptr) {
        if (afterFork) {
            accClient_->StopAfterFork();
        } else {
            accClient_->Stop();
        }
        accClient_ = nullptr;
    }

    if (accServer_ != nullptr) {
        accServer_->Shutdown(afterFork);
        accServer_ = nullptr;
    }
    sockFd_ = -1;
}

Result TcpConfigStore::Set(const std::string &key, const std::vector<uint8_t> &value) noexcept
{
    if (key.empty() || key.length() > MAX_KEY_LEN_CLIENT) {
        SHM_LOG_ERROR("key length is invalid");
        return StoreErrorCode::INVALID_KEY;
    }

    SmemMessage request{MessageType::SET};
    request.keys.push_back(key);
    request.values.push_back(value);

    auto packedRequest = SmemMessagePacker::Pack(request);
    auto response = SendMessageBlocked(packedRequest);
    if (response == nullptr) {
        SHM_LOG_ERROR("send set for key: " << key << ", get null response");
        return IO_ERROR;
    }

    auto responseCode = response->Header().result;
    if (responseCode != 0) {
        SHM_LOG_ERROR("send set for key: " << key << ", get response code: " << responseCode);
    }

    return responseCode;
}

Result TcpConfigStore::GetReal(const std::string &key, std::vector<uint8_t> &value, int64_t timeoutMs) noexcept
{
    if (key.empty() || key.length() > MAX_KEY_LEN_CLIENT) {
        SHM_LOG_ERROR("key length is invalid");
        return StoreErrorCode::INVALID_KEY;
    }

    SmemMessage request{MessageType::GET};
    request.keys.push_back(key);
    request.userDef = timeoutMs;

    auto packedRequest = SmemMessagePacker::Pack(request);
    auto response = SendMessageBlocked(packedRequest, timeoutMs);
    if (response == nullptr) {
        SHM_LOG_ERROR("send get for key: " << key << ", get null response");
        return IO_ERROR;
    }

    auto responseCode = response->Header().result;
    if (responseCode != 0) {
        if (responseCode != NOT_EXIST) {
            SHM_LOG_ERROR("send get for key: " << key << ", resp code: " << responseCode << " timeout:" << timeoutMs);
        }
        return responseCode;
    }

    auto data = reinterpret_cast<const uint8_t *>(response->DataPtr());
    SmemMessage responseBody;
    auto ret = SmemMessagePacker::Unpack(data, response->DataLen(), responseBody);
    if (ret < 0) {
        SHM_LOG_ERROR("unpack response body failed, result: " << ret);
        return -1;
    }

    if (responseBody.values.empty()) {
        SHM_LOG_ERROR("response body has no value");
        return -1;
    }

    value = std::move(responseBody.values[0]);
    return 0;
}

Result TcpConfigStore::Add(const std::string &key, int64_t increment, int64_t &value) noexcept
{
    if (key.empty() || key.length() > MAX_KEY_LEN_CLIENT) {
        SHM_LOG_ERROR("key length is invalid");
        return StoreErrorCode::INVALID_KEY;
    }

    SmemMessage request{MessageType::ADD};
    request.keys.push_back(key);
    std::string inc = std::to_string(increment);
    request.values.push_back(std::vector<uint8_t>(inc.begin(), inc.end()));

    auto packedRequest = SmemMessagePacker::Pack(request);
    auto response = SendMessageBlocked(packedRequest);
    if (response == nullptr) {
        SHM_LOG_ERROR("send add for key: " << key << ", get null response");
        return StoreErrorCode::IO_ERROR;
    }

    auto responseCode = response->Header().result;
    if (responseCode != 0) {
        SHM_LOG_ERROR("send add for key: " << key << ", get response code: " << responseCode);
        return responseCode;
    }

    std::string data(reinterpret_cast<char *>(response->DataPtr()), response->DataLen());
    SHM_VALIDATE_RETURN(StrToLong(data, value), "convert string to long failed.", StoreErrorCode::ERROR);
    return StoreErrorCode::SUCCESS;
}

Result TcpConfigStore::Remove(const std::string &key, bool printKeyNotExist) noexcept
{
    if (key.empty() || key.length() > MAX_KEY_LEN_CLIENT) {
        SHM_LOG_ERROR("key length is invalid");
        return StoreErrorCode::INVALID_KEY;
    }

    SmemMessage request{MessageType::REMOVE};
    request.keys.push_back(key);

    auto packedRequest = SmemMessagePacker::Pack(request);
    auto response = SendMessageBlocked(packedRequest);
    if (response == nullptr) {
        SHM_LOG_ERROR("send remove for key: " << key << ", get null response");
        return StoreErrorCode::IO_ERROR;
    }

    auto responseCode = response->Header().result;
    if (responseCode == StoreErrorCode::NOT_EXIST) {
        if (printKeyNotExist) {
            // Do not need to print ERROR message when sending remove key which is already not exist.
            SHM_LOG_INFO("send remove for key: " << key << ", is already not exist");
        }
    } else if (responseCode != 0) {
        SHM_LOG_ERROR("send remove for key: " << key << ", get response code: " << responseCode);
    }

    return responseCode;
}

Result TcpConfigStore::Append(const std::string &key, const std::vector<uint8_t> &value, uint64_t &newSize) noexcept
{
    if (key.empty() || key.length() > MAX_KEY_LEN_CLIENT) {
        SHM_LOG_ERROR("key length is invalid");
        return StoreErrorCode::INVALID_KEY;
    }

    SmemMessage request{MessageType::APPEND};
    request.keys.push_back(key);
    request.values.push_back(value);

    auto packedRequest = SmemMessagePacker::Pack(request);
    auto response = SendMessageBlocked(packedRequest);
    if (response == nullptr) {
        SHM_LOG_ERROR("send append for key: " << key << ", get null response");
        return StoreErrorCode::IO_ERROR;
    }

    auto responseCode = response->Header().result;
    if (responseCode != 0) {
        SHM_LOG_ERROR("send append for key: " << key << ", get response code: " << responseCode);
        return responseCode;
    }

    std::string data(reinterpret_cast<char *>(response->DataPtr()), response->DataLen());

    long tmpValue = 0;
    SHM_VALIDATE_RETURN(StrToLong(data, tmpValue), "convert string to long failed.", StoreErrorCode::ERROR);
    newSize = static_cast<uint64_t>(tmpValue);

    return StoreErrorCode::SUCCESS;
}

Result TcpConfigStore::Cas(const std::string &key, const std::vector<uint8_t> &expect,
                           const std::vector<uint8_t> &value, std::vector<uint8_t> &exists) noexcept
{
    if (key.empty() || key.length() > MAX_KEY_LEN_CLIENT) {
        SHM_LOG_ERROR("key length is invalid");
        return StoreErrorCode::INVALID_KEY;
    }

    SmemMessage request{MessageType::CAS};
    request.keys.push_back(key);
    request.values.push_back(expect);
    request.values.push_back(value);

    auto packedRequest = SmemMessagePacker::Pack(request);
    auto response = SendMessageBlocked(packedRequest);
    if (response == nullptr) {
        SHM_LOG_ERROR("send CAS for key: " << key << ", get null response");
        return StoreErrorCode::IO_ERROR;
    }

    auto responseCode = response->Header().result;
    if (responseCode != 0) {
        SHM_LOG_ERROR("send CAS for key: " << key << ", get response code: " << responseCode);
        return responseCode;
    }

    auto data = reinterpret_cast<const uint8_t *>(response->DataPtr());
    SmemMessage responseBody;
    auto ret = SmemMessagePacker::Unpack(data, response->DataLen(), responseBody);
    if (ret < 0) {
        SHM_LOG_ERROR("unpack response body failed, result: " << ret);
        return -1;
    }

    if (responseBody.values.empty()) {
        SHM_LOG_ERROR("response body has no value");
        return -1;
    }

    exists = std::move(responseBody.values[0]);
    return 0;
}

Result TcpConfigStore::Watch(
    const std::string &key,
    const std::function<void(int result, const std::string &, const std::vector<uint8_t> &)> &notify,
    uint32_t &wid) noexcept
{
    if (key.empty() || key.length() > MAX_KEY_LEN_CLIENT) {
        SHM_LOG_ERROR("key length is invalid");
        return StoreErrorCode::INVALID_KEY;
    }

    SmemMessage request{MessageType::GET};
    request.keys.push_back(key);

    auto packedRequest = SmemMessagePacker::Pack(request);
    auto ret = SendWatchRequest(
        packedRequest, [key, notify](int res, const std::vector<uint8_t> &value) { notify(res, key, value); }, wid);
    if (ret != SM_OK) {
        SHM_LOG_ERROR("send get for key: " << key << ", get null response");
        return ret;
    }

    SHM_LOG_DEBUG("watch for key: " << key << ", id: " << wid);
    return SM_OK;
}

Result TcpConfigStore::Unwatch(uint32_t wid) noexcept
{
    std::shared_ptr<ClientCommonContext> watchContext;

    std::unique_lock<std::mutex> msgCtxLocker{msgCtxMutex_};
    auto pos = msgClientContext_.find(wid);
    if (pos != msgClientContext_.end() && !pos->second->Blocking()) {
        watchContext = std::move(pos->second);
        msgClientContext_.erase(pos);
    }
    msgCtxLocker.unlock();

    if (watchContext == nullptr) {
        SHM_LOG_INFO("unwatch for id: " << wid << ", not exist.");
        return NOT_EXIST;
    }

    SHM_LOG_INFO("unwatch for id: " << wid << " success.");
    return SM_OK;
}

std::shared_ptr<shm::acc::AccTcpRequestContext> TcpConfigStore::SendMessageBlocked(
    const std::vector<uint8_t> &reqBody,
    int64_t timeoutMs) noexcept
{
    if (accClientLink_ == nullptr) {
        SHM_LOG_ERROR("accClientLink_ is null, connection not established");
        return nullptr;
    }

    auto seqNo = reqSeqGen_.fetch_add(1U);

    auto waitContext = std::make_shared<ClientWaitContext>(timeoutMs);

    std::unique_lock<std::mutex> msgCtxLocker{msgCtxMutex_};
    msgClientContext_.emplace(seqNo, waitContext);
    msgCtxLocker.unlock();

    auto dataBuf = shm::acc::AccDataBuffer::Create(reqBody.data(), reqBody.size());
    auto ret = accClientLink_->NonBlockSend(0, seqNo, dataBuf, nullptr);
    if (ret != SM_OK) {
        SHM_LOG_ERROR("send message failed, result: " << ret);
        std::unique_lock<std::mutex> locker{msgCtxMutex_};
        msgClientContext_.erase(seqNo);
        return nullptr;
    }

    auto response = waitContext->WaitFinished();
    if (response == nullptr) {
        std::unique_lock<std::mutex> locker{msgCtxMutex_};
        msgClientContext_.erase(seqNo);
    }
    return response;
}

Result TcpConfigStore::LinkBrokenHandler(const shm::acc::AccTcpLinkComplexPtr &link) noexcept
{
    SHM_LOG_INFO("link broken, linkId: " << link->Id());
    std::unordered_map<uint32_t, std::shared_ptr<ClientCommonContext>> tempContext;
    std::unique_lock<std::mutex> msgCtxLocker{msgCtxMutex_};
    tempContext.swap(msgClientContext_);
    msgCtxLocker.unlock();

    for (auto &it : tempContext) {
        it.second->SetFailedFinish();
    }

    return SM_OK;
}

Result TcpConfigStore::ReceiveResponseHandler(const shm::acc::AccTcpRequestContext &context) noexcept
{
    SHM_LOG_DEBUG("client received message: " << context.SeqNo());
    std::shared_ptr<ClientCommonContext> clientContext;

    std::unique_lock<std::mutex> msgCtxLocker{msgCtxMutex_};
    auto pos = msgClientContext_.find(context.SeqNo());
    if (pos != msgClientContext_.end()) {
        clientContext = std::move(pos->second);
        msgClientContext_.erase(pos);
    }
    msgCtxLocker.unlock();

    if (clientContext == nullptr) {
        SHM_LOG_ERROR("receive response(" << context.SeqNo() << ") not sent request.");
        return SM_ERROR;
    }

    clientContext->SetFinished(context);
    return SM_OK;
}

Result TcpConfigStore::SendWatchRequest(const std::vector<uint8_t> &reqBody,
                                        const std::function<void(int result, const std::vector<uint8_t> &)> &notify,
                                        uint32_t &id) noexcept
{
    if (accClientLink_ == nullptr) {
        SHM_LOG_ERROR("accClientLink_ is null, connection not established");
        return SM_ERROR;
    }

    auto seqNo = reqSeqGen_.fetch_add(1U);

    auto watchContext = std::make_shared<ClientWatchContext>(notify);
    std::unique_lock<std::mutex> msgCtxLocker{msgCtxMutex_};
    msgClientContext_.emplace(seqNo, std::move(watchContext));
    msgCtxLocker.unlock();

    auto dataBuf = shm::acc::AccDataBuffer::Create(reqBody.data(), reqBody.size());
    auto ret = accClientLink_->NonBlockSend(0, seqNo, dataBuf, nullptr);
    if (ret != SM_OK) {
        SHM_LOG_ERROR("send message failed, result: " << ret);
        std::unique_lock<std::mutex> locker{msgCtxMutex_};
        msgClientContext_.erase(seqNo);
        return ret;
    }

    id = seqNo;
    return SM_OK;
}
}  // namespace store
}  // namespace shm