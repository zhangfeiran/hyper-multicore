/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */
#ifndef ACC_LINKS_ACC_TCP_LISTENER_H
#define ACC_LINKS_ACC_TCP_LISTENER_H

#include "sotre_net.h"
#include "acc_includes.h"
#include "acc_tcp_common.h"
#include "acc_tcp_link.h"
#include "acc_tcp_link_complex_default.h"

namespace shm {
namespace acc {
using NewConnHandlerInner = std::function<int(const AccConnReq &reg, const AccTcpLinkComplexDefaultPtr &)>;

class AccTcpListener : public AccReferable {
public:
    AccTcpListener(std::string ip, uint16_t port, bool reusePort, int32_t sockFd = -1,
                   bool enableTls = false, SSL_CTX *sslCtx = nullptr)
        : listenIp_(std::move(ip)),
          listenPort_(port),
          reusePort_(reusePort),
          listenFd_(sockFd),
          enableTls_(enableTls),
          sslCtx_(sslCtx)
    {
    }

    ~AccTcpListener() override = default;

    void RegisterNewConnectionHandler(const NewConnHandlerInner &h);

    Result Start() noexcept;
    void Stop(bool afterFork = false) noexcept;

private:
    void RunInThread() noexcept;
    void ProcessNewConnection(int fd, mf_sockaddr addressIn) noexcept;
    bool PrepareSockAddr(mf_sockaddr& addr) noexcept;
    Result StartAcceptThread() noexcept;
    Result CreateSocketForStrat(mf_sockaddr &addr, int &tmpFD) noexcept;
    void FormatIPAddressAndPort(mf_sockaddr addressIn, std::string &ipPort) noexcept;
    Result BindAndListenSocket(int tmpFD, mf_sockaddr &addr) noexcept;
    inline std::string NameAndPort() const noexcept;

private:
    int listenFd_ = -1; /* listen fd */
    volatile bool needStop_ = false; /* stop thread flag */
    NewConnHandlerInner connHandler_ = nullptr; /* new connection handler */
    std::thread acceptThread_; /* accept thread */
    bool started_ = false; /* listener started or not */
    std::atomic<bool> threadStarted_{false}; /* flag to ensure thread started */
    const std::string listenIp_; /* listen ip */
    const uint16_t listenPort_; /* listen port */
    const bool reusePort_; /* reuse listen port or not */
    const bool enableTls_; /* enable tls */
    SSL_CTX* sslCtx_ = nullptr; /* ssl ctx */
    IpType ipType_ {IPNONE}; /* listenIp_ is ipv4 or ipv6 */
};
using AccTcpListenerPtr = AccRef<AccTcpListener>;

inline void AccTcpListener::RegisterNewConnectionHandler(const NewConnHandlerInner &h)
{
    ASSERT_RET_VOID(h != nullptr);
    ASSERT_RET_VOID(connHandler_ == nullptr);
    connHandler_ = h;
}

inline std::string AccTcpListener::NameAndPort() const noexcept
{
    if (ipType_ == IpV4) {
        return listenIp_ + ":" + std::to_string(listenPort_);
    } else if (ipType_ == IpV6) {
        return "[" + listenIp_ + "]:" + std::to_string(listenPort_);
    }
    return "";
}
}  // namespace acc
}  // namespace shm

#endif  // ACC_LINKS_ACC_TCP_LISTENER_H
