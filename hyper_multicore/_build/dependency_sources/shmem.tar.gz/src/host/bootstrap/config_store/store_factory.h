/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */


#ifndef SMEM_SMEM_STORE_FACTORY_H
#define SMEM_SMEM_STORE_FACTORY_H

#include <set>
#include <string>
#include <thread>
#include <chrono>
#include <unordered_map>
#include <functional>
#include <condition_variable>
#include <atomic>
#include "store_op.h"
#include "store_utils.h"

namespace shm {
namespace store {

class StoreFactory {
public:
    /**
     * @brief Create a new store
     * @param ip server ip address
     * @param port server tcp port
     * @param isServer is local store server side
     * @param rankId rank id, default 0
     * @param connMaxRetry Maximum number of retry times for the client to connect to the server.
     * @param sockFd listen socket fd, default -1
     * @param magic session magic for distinguishing init/finalize cycles, default SMEM_DEFAULT_CONN_MAGIC
     * @return Newly created store
     */
    static StorePtr CreateStore(const std::string &ip, uint16_t port, bool isServer, int32_t rankId = 0,
        int32_t connMaxRetry = -1, int32_t sockFd = -1, uint16_t magic = SMEM_DEFAULT_CONN_MAGIC) noexcept;

    /**
     * @brief Destroy on exist store
     * @param ip server ip address
     * @param port server tcp port
     */
    static void DestroyStore() noexcept;
    static void DestroyStoreAll(bool afterFork = false) noexcept;

    /**
     * @brief Encapsulate an existing store into a prefix store.
     * @param base existing store
     * @param prefix Prefix of keys
     * @return prefix store.
     */
    static StorePtr PrefixStore(const StorePtr &base, const std::string &prefix) noexcept;

    static int GetFailedReason() noexcept;

    /**
     * @brief Init and set tls info.
     * @param enable whether to enable tls
     * @param tlsData the tls config info
     * @param tlsDataLen the length of tls config info
     * @return Returns 0 on success or an error code on failure
     */
    static int32_t SetTlsInfo(bool enable, const char *tlsData, const size_t tlsDataLen) noexcept;

    /**
     * @brief Set the TLS private key and password.
     * @param enable whether to enable tls
     * @param tlsInfo the tls config info
     * @param tlsInfoLen the length of tls config info
     * @param tlsInfo the tls config info
     * @param tlsInfoLen the length of tls config info
     * @return Returns 0 on success or an error code on failure
     */
    static int32_t SetTlsPkInfo(const char *tlsPk, const uint32_t tlsPkLen, const char *tlsPkPwd,
        const uint32_t tlsPkPwLen, const smem_decrypt_handler &h) noexcept;

    static void ShutDownCleanupThread() noexcept;

private:
    static Result InitTlsOption() noexcept;
    static void TlsCleanUp() noexcept;
    static std::function<int(const std::string&, char*, size_t&)>
        ConvertFunc(int (*rawFunc)(const char*, size_t, char*, size_t &)) noexcept;
    static bool enableTls;
    static std::string tlsInfo;
    static std::string tlsPkInfo;
    static std::string tlsPkPwdInfo;

private:
    static std::mutex storesMutex_;
    static AcclinkTlsOption tlsOption_;
    static bool isTlsInitialized_;
    static std::thread cleanerThread_;
    static std::atomic<bool> timerRunning_;
    static std::condition_variable cv_;
    static std::atomic<bool> stop_;
};
} // namespace store
} // namespace shm

#endif // SMEM_SMEM_STORE_FACTORY_H
