/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */


#ifndef SMEM_SMEM_TCP_CONFIG_STORE_H
#define SMEM_SMEM_TCP_CONFIG_STORE_H

#include <atomic>
#include <condition_variable>
#include <memory>

#include "store_op.h"
#include "store_tcp_config_server.h"

namespace shm {
namespace store {

// Default SEND/RECV timeout (ms) for operations without user-specified timeout.
// Aligned with SMEM_DEFAUT_WAIT_TIME to match control_operation_timeout semantics.
constexpr int64_t kDefaultSendMsgTimeoutMs = SMEM_DEFAUT_WAIT_TIME * 1000;

class ClientCommonContext {
public:
    virtual ~ClientCommonContext() = default;
    virtual std::shared_ptr<shm::acc::AccTcpRequestContext> WaitFinished() noexcept = 0;
    virtual void SetFinished(const shm::acc::AccTcpRequestContext &response) noexcept = 0;
    virtual void SetFailedFinish() noexcept = 0;
    virtual bool Blocking() const noexcept = 0;
};

class TcpConfigStore : public ConfigStore {
public:
    TcpConfigStore(std::string ip, uint16_t port, bool isServer, int32_t rankId = 0, int32_t sockFd = -1,
                   uint16_t magic = SMEM_DEFAULT_CONN_MAGIC) noexcept;
    ~TcpConfigStore() noexcept override;

    Result Startup(const AcclinkTlsOption &tlsOption, int reconnectRetryTimes = -1) noexcept;
    void Shutdown(bool afterFork = false) noexcept;

    Result Set(const std::string &key, const std::vector<uint8_t> &value) noexcept override;
    Result Add(const std::string &key, int64_t increment, int64_t &value) noexcept override;
    Result Remove(const std::string &key, bool printKeyNotExist) noexcept override;
    Result Append(const std::string &key, const std::vector<uint8_t> &value, uint64_t &newSize) noexcept override;
    Result Cas(const std::string &key, const std::vector<uint8_t> &expect, const std::vector<uint8_t> &value,
               std::vector<uint8_t> &exists) noexcept override;
    Result Watch(const std::string &key,
                 const std::function<void(int result, const std::string &, const std::vector<uint8_t> &)> &notify,
                 uint32_t &wid) noexcept override;
    Result Unwatch(uint32_t wid) noexcept override;
    std::string GetCompleteKey(const std::string &key) noexcept override
    {
        return key;
    }

    std::string GetCommonPrefix() noexcept override
    {
        return "";
    }

    StorePtr GetCoreStore() noexcept override
    {
        return this;
    }

protected:
    Result GetReal(const std::string &key, std::vector<uint8_t> &value, int64_t timeoutMs) noexcept override;

private:
    std::shared_ptr<shm::acc::AccTcpRequestContext> SendMessageBlocked(
        const std::vector<uint8_t> &reqBody,
        int64_t timeoutMs = kDefaultSendMsgTimeoutMs) noexcept;
    Result LinkBrokenHandler(const shm::acc::AccTcpLinkComplexPtr &link) noexcept;
    Result ReceiveResponseHandler(const shm::acc::AccTcpRequestContext &context) noexcept;
    Result SendWatchRequest(const std::vector<uint8_t> &reqBody,
                            const std::function<void(int result, const std::vector<uint8_t> &)> &notify,
                            uint32_t &id) noexcept;

    Result AccClientStart(const AcclinkTlsOption &tlsOption) noexcept;

private:
    AccStoreServerPtr accServer_;
    shm::acc::AccTcpServerPtr accClient_;
    shm::acc::AccTcpLinkComplexPtr accClientLink_;

    std::mutex msgCtxMutex_;
    std::unordered_map<uint32_t, std::shared_ptr<ClientCommonContext>> msgClientContext_;
    static std::atomic<uint32_t> reqSeqGen_;

    std::mutex mutex_;
    const std::string serverIp_;
    const uint16_t serverPort_;
    const bool isServer_;
    const int32_t rankId_;
    int32_t sockFd_;
    uint16_t magic_;
};
using TcpConfigStorePtr = SmRef<TcpConfigStore>;
}  // namespace store
}  // namespace shm

#endif  // SMEM_SMEM_TCP_CONFIG_STORE_H
