/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */
#include <thread>
#include <algorithm>
#include "shmemi_logger.h"
#include "dl_acl_api.h"
#include "dl_hccp_api.h"
#include "dynamic_ranks_qp_manager.h"

namespace shm {
namespace transport {
namespace device {
const int delay = 5;
static constexpr auto WAIT_DELAY_TIME = std::chrono::seconds(delay);
DynamicRanksQpManager::DynamicRanksQpManager(
    uint32_t userDeviceId, uint32_t deviceId, uint32_t rankId, uint32_t rankCount, mf_sockaddr devNet,
    bool server) noexcept
    : DeviceQpManager{
          deviceId, rankId, rankCount, devNet,
          server ? hybm_role_type::HYBM_ROLE_RECEIVER : hybm_role_type::HYBM_ROLE_SENDER}
{
    connectionView_.resize(rankCount);
    userDeviceId_ = userDeviceId;
}

DynamicRanksQpManager::~DynamicRanksQpManager() noexcept
{
    try {
        CloseServices();
    } catch (const std::exception& e) {
        SHM_LOG_ERROR("dynamic ranks qp mgr close services failed: " << e.what());
    }
}

int DynamicRanksQpManager::SetRemoteRankInfo(const std::unordered_map<uint32_t, ConnectRankInfo>& ranks) noexcept
{
    std::unordered_map<uint32_t, ConnectRankInfo> tempRanks;
    for (auto it = ranks.begin(); it != ranks.end(); ++it) {
        if (it->second.role == rankRole_) {
            continue;
        }

        if (it->first >= rankCount_) {
            SHM_LOG_ERROR("contains too large rankId: " << it->first);
            return ACLSHMEM_INNER_ERROR;
        }

        tempRanks.emplace(it->first, it->second);
    }

    std::unordered_map<uint32_t, mf_sockaddr> addedRanks;
    std::unordered_set<uint32_t> addMrRanks;

    std::unique_lock<std::mutex> uniqueLock{mutex_};
    auto lastTimeRanksInfo = std::move(currentRanksInfo_);
    currentRanksInfo_ = std::move(tempRanks);
    if (backGroundThread_ == nullptr) {
        return ACLSHMEM_SUCCESS;
    }
    SHM_LOG_DEBUG(
        "SetRemoteRankInfo currentRanksInfo_.size=: " << currentRanksInfo_.size()
                                                      << ", lastTimeRanksInfo.size=" << lastTimeRanksInfo.size());
    GenDiffInfoChangeRanks(lastTimeRanksInfo, addedRanks, addMrRanks);
    uniqueLock.unlock();

    GenTaskFromChangeRanks(addedRanks, addMrRanks);
    return ACLSHMEM_SUCCESS;
}

int DynamicRanksQpManager::SetLocalMemories(const MemoryRegionMap& mrs) noexcept
{
    std::unique_lock<std::mutex> uniqueLock{mutex_};
    currentLocalMrs_ = mrs;
    if (backGroundThread_ == nullptr) {
        return ACLSHMEM_SUCCESS;
    }
    uniqueLock.unlock();

    auto& task = connectionTasks_.updateMrTask;
    std::unique_lock<std::mutex> taskLocker{task.locker};
    task.status.exist = true;
    task.status.failedTimes = 0;
    taskLocker.unlock();
    cond_.notify_one();

    return ACLSHMEM_SUCCESS;
}

int DynamicRanksQpManager::Startup(void* rdma) noexcept
{
    if (rdma == nullptr) {
        SHM_LOG_ERROR("input rdma is null");
        return ACLSHMEM_INVALID_PARAM;
    }

    rdmaHandle_ = rdma;
    std::unique_lock<std::mutex> uniqueLock{mutex_};
    if (rankRole_ == hybm_role_type::HYBM_ROLE_RECEIVER) {
        auto ret = CreateServerSocket();
        if (ret != ACLSHMEM_SUCCESS) {
            SHM_LOG_ERROR("create server socket failed: " << ret);
            return ret;
        }

        auto& task = connectionTasks_.whitelistTask;
        task.locker.lock();
        for (auto it = currentRanksInfo_.begin(); it != currentRanksInfo_.end(); ++it) {
            net_addr_t remoteIp;
            if (it->second.network.type == IpV4) {
                remoteIp.type = IpV4;
                remoteIp.ip.ipv4 = it->second.network.ip.ipv4.sin_addr;
            } else if (it->second.network.type == IpV6) {
                remoteIp.type = IpV6;
                remoteIp.ip.ipv6 = it->second.network.ip.ipv6.sin6_addr;
            }
            task.remoteIps.emplace(it->first, remoteIp);
        }
        task.status.failedTimes = 0;
        task.status.exist = true;
        task.locker.unlock();
    } else {
        auto& task = connectionTasks_.clientConnectTask;
        task.locker.lock();
        for (auto it = currentRanksInfo_.begin(); it != currentRanksInfo_.end(); ++it) {
            task.remoteAddress.emplace(it->first, it->second.network);
        }
        task.status.failedTimes = 0;
        task.status.exist = true;
        task.locker.unlock();
    }

    if (backGroundThread_ != nullptr) {
        SHM_LOG_ERROR("already started");
        return ACLSHMEM_INNER_ERROR;
    }

    managerRunning_.store(true);
    backGroundThread_ = std::make_shared<std::thread>([this]() { BackgroundProcess(); });
    return ACLSHMEM_SUCCESS;
}

void DynamicRanksQpManager::Shutdown() noexcept { CloseServices(); }

void* DynamicRanksQpManager::GetQpHandleWithRankId(uint32_t rankId) const noexcept
{
    if (rankId >= connectionView_.size()) {
        SHM_LOG_ERROR("get qp handle with rankId: " << rankId << ", too large.");
        return nullptr;
    }

    auto conn = connectionView_[rankId];
    if (conn == nullptr) {
        SHM_LOG_ERROR("get qp handle with rankId: " << rankId << ", no connection.");
        return nullptr;
    }

    return conn->qpHandle;
}

void DynamicRanksQpManager::BackgroundProcess() noexcept
{
    DlAclApi::AclrtSetDevice(userDeviceId_);
    while (managerRunning_.load()) {
        auto count = ProcessServerAddWhitelistTask();
        count += ProcessClientConnectSocketTask();
        count += ProcessQueryConnectionStateTask();
        count += ProcessConnectQpTask();
        count += ProcessQueryQpStateTask();
        ProcessUpdateLocalMrTask();
        ProcessUpdateRemoteMrTask();
        if (count > 0) {
            continue;
        }

        std::unique_lock<std::mutex> uniqueLock{mutex_};
        if (managerRunning_) {
            cond_.wait_for(uniqueLock, std::chrono::minutes(1));
        }
        uniqueLock.unlock();
    }
}

void DynamicRanksQpManager::InitializeWhiteList(
    std::vector<HccpSocketWhiteListInfo>& whitelist, std::unordered_map<uint32_t, net_addr_t> remotes) noexcept
{
    const uint32_t MAX_CONNECTIONS = 1024;
    for (auto it = remotes.begin(); it != remotes.end(); ++it) {
        if (connections_.find(it->first) != connections_.end()) {
            continue;
        }

        HccpSocketWhiteListInfo info{};
        net_addr_t addr;
        if (it->second.type == IpV4) {
            info.remoteIp.addr = it->second.ip.ipv4;
            addr.type = IpV4;
            addr.ip.ipv4 = info.remoteIp.addr;
        } else if (it->second.type == IpV6) {
            info.remoteIp.addr6 = it->second.ip.ipv6;
            addr.type = IpV6;
            addr.ip.ipv6 = info.remoteIp.addr6;
        }
        info.connLimit = MAX_CONNECTIONS;
        bzero(info.tag, sizeof(info.tag));
        whitelist.emplace_back(info);
        auto res = connections_.emplace(it->first, ConnectionChannel{addr, serverSocketHandle_});
        connectionView_[it->first] = &res.first->second;
        SHM_LOG_INFO("connections list add rank: " << it->first << ", remoteIP: " << inet_ntoa(info.remoteIp.addr));
    }
}

int DynamicRanksQpManager::ProcessServerAddWhitelistTask() noexcept
{
    if (rankRole_ != hybm_role_type::HYBM_ROLE_RECEIVER) {
        return 0;
    }

    auto& currTask = connectionTasks_.whitelistTask;
    std::unique_lock<std::mutex> uniqueLock{currTask.locker};
    if (!currTask.status.exist) {
        return 0;
    }

    auto remotes = std::move(currTask.remoteIps);
    currTask.status.exist = false;
    uniqueLock.unlock();

    std::vector<HccpSocketWhiteListInfo> whitelist;
    InitializeWhiteList(whitelist, remotes);

    if (whitelist.empty()) {
        return 0;
    }

    auto ret = DlHccpApi::RaSocketWhiteListAdd(serverSocketHandle_, whitelist.data(), whitelist.size());
    if (ret != 0) {
        auto failedTimes = currTask.Failed(remotes);
        SHM_LOG_ERROR(
            "RaSocketWhiteListAdd() with size=" << whitelist.size() << " failed: " << ret << ", times=" << failedTimes);
        return 1;
    }

    currTask.Success();
    auto& nextTask = connectionTasks_.queryConnectTask;
    for (auto& rank : remotes) {
        net_addr_t rankIp;
        if (rank.second.type == IpV4) {
            rankIp.type = IpV4;
            rankIp.ip.ipv4 = rank.second.ip.ipv4;
        } else if (rank.second.type == IpV6) {
            rankIp.type = IpV6;
            rankIp.ip.ipv6 = rank.second.ip.ipv6;
        }
        nextTask.ip2rank.emplace(rankIp, rank.first);
    }
    nextTask.status.exist = true;
    nextTask.status.failedTimes = 0;
    return 0;
}

int DynamicRanksQpManager::CreateConnectInfos(
    std::unordered_map<uint32_t, mf_sockaddr>& remotes, std::vector<HccpSocketConnectInfo>& connectInfos,
    ClientConnectSocketTask& currTask)
{
    for (auto it = remotes.begin(); it != remotes.end(); ++it) {
        void* socketHandle;
        auto pos = connections_.find(it->first);
        if (pos == connections_.end()) {
            socketHandle = CreateLocalSocket();
            if (socketHandle == nullptr) {
                auto failedCount = currTask.Failed(remotes);
                SHM_LOG_ERROR("create local socket handle failed times: " << failedCount);
                return 1;
            }
            net_addr_t remoteIp;
            if (it->second.type == IpV4) {
                remoteIp.type = IpV4;
                remoteIp.ip.ipv4 = it->second.ip.ipv4.sin_addr;
            } else if (it->second.type == IpV6) {
                remoteIp.type = IpV6;
                remoteIp.ip.ipv6 = it->second.ip.ipv6.sin6_addr;
            }
            pos = connections_.emplace(it->first, ConnectionChannel{remoteIp, socketHandle}).first;
            connectionView_[it->first] = &pos->second;
        } else {
            socketHandle = pos->second.socketHandle;
        }

        if (pos->second.socketFd != nullptr) {
            continue;
        }

        HccpSocketConnectInfo connectInfo;
        connectInfo.handle = socketHandle;
        if (it->second.type == IpV4) {
            connectInfo.remoteIp.addr = it->second.ip.ipv4.sin_addr;
            connectInfo.port = it->second.ip.ipv4.sin_port;
        } else if (it->second.type == IpV6) {
            connectInfo.remoteIp.addr6 = it->second.ip.ipv6.sin6_addr;
            connectInfo.port = it->second.ip.ipv6.sin6_port;
        }
        bzero(connectInfo.tag, sizeof(connectInfo.tag));
        SHM_LOG_INFO("add connecting server " << connectInfo);
        connectInfos.emplace_back(connectInfo);
    }
    return ACLSHMEM_SUCCESS;
}

int DynamicRanksQpManager::BatchConnectWithRetry(
    std::vector<HccpSocketConnectInfo> connectInfos, ClientConnectSocketTask& currTask,
    std::unordered_map<uint32_t, mf_sockaddr>& remotes) noexcept
{
    uint32_t batchSize = 16;
    for (size_t i = 0; i < connectInfos.size(); i += batchSize) {
        size_t currentBatchSize = (connectInfos.size() - i) >= batchSize ? batchSize : (connectInfos.size() - i);
        auto batchStart = connectInfos.begin() + i;
        auto batchEnd = batchStart + currentBatchSize;
        std::vector<HccpSocketConnectInfo> currentBatch(batchStart, batchEnd);

        auto ret = DlHccpApi::RaSocketBatchConnect(currentBatch.data(), currentBatch.size());
        if (ret != 0) {
            auto failedCount = currTask.Failed(remotes);
            SHM_LOG_ERROR(
                "connect to all servers failed: " << ret << ", servers count = " << connectInfos.size()
                                                  << ", failed times: " << failedCount);
            return 1;
        }
    }
    return 0;
}

int DynamicRanksQpManager::ProcessClientConnectSocketTask() noexcept
{
    if (rankRole_ != hybm_role_type::HYBM_ROLE_SENDER) {
        return 0;
    }

    auto& currTask = connectionTasks_.clientConnectTask;
    std::unique_lock<std::mutex> uniqueLock{currTask.locker};
    if (!currTask.status.exist) {
        return 0;
    }

    std::this_thread::sleep_for(WAIT_DELAY_TIME);
    auto remotes = std::move(currTask.remoteAddress);
    currTask.status.exist = false;
    uniqueLock.unlock();

    std::vector<HccpSocketConnectInfo> connectInfos;
    auto ret = CreateConnectInfos(remotes, connectInfos, currTask);
    if (ret != 0) {
        return ret;
    }

    if (connectInfos.empty()) {
        SHM_LOG_INFO("no connections now.");
        return 0;
    }

    if (BatchConnectWithRetry(connectInfos, currTask, remotes) != 0) {
        return 1;
    }

    currTask.Success();
    auto& nextTask = connectionTasks_.queryConnectTask;
    for (auto& rank : remotes) {
        net_addr_t rankIp;
        if (rank.second.type == IpV4) {
            rankIp.type = IpV4;
            rankIp.ip.ipv4 = rank.second.ip.ipv4.sin_addr;
        } else if (rank.second.type == IpV6) {
            rankIp.type = IpV6;
            rankIp.ip.ipv6 = rank.second.ip.ipv6.sin6_addr;
        }
        nextTask.ip2rank.emplace(rankIp, rank.first);
    }
    nextTask.status.exist = true;
    nextTask.status.failedTimes = 0;
    return 0;
}

void DynamicRanksQpManager::Parse2SocketInfo(
    std::unordered_map<net_addr_t, uint32_t>& ip2rank, std::vector<HccpSocketInfo>& socketInfos,
    std::vector<IpType>& types)
{
    for (auto& pair : ip2rank) {
        struct net_addr_t ip;
        if (pair.first.type == IpV4) {
            ip.type = IpV4;
            ip.ip.ipv4 = pair.first.ip.ipv4;
        } else if (pair.first.type == IpV6) {
            ip.type = IpV6;
            ip.ip.ipv6 = pair.first.ip.ipv6;
        }

        auto pos = connections_.find(pair.second);
        if (pos != connections_.end()) {
            HccpSocketInfo info;
            info.handle = pos->second.socketHandle;
            info.fd = nullptr;
            if (pos->second.remoteIp.type == IpV4) {
                info.remoteIp.addr = pos->second.remoteIp.ip.ipv4;
            } else if (pos->second.remoteIp.type == IpV6) {
                info.remoteIp.addr6 = pos->second.remoteIp.ip.ipv6;
            }
            info.status = 0;
            bzero(info.tag, sizeof(info.tag));
            socketInfos.emplace_back(info);
            types.emplace_back(pos->second.remoteIp.type);
        }
    }
    if (socketInfos.size() == 0) {
        SHM_LOG_INFO("ProcessQueryConnectionStateTask socketInfos.size is 0.");
    }
}

void DynamicRanksQpManager::ProcessSocketConnectionsByIP(
    uint32_t getSize, std::vector<HccpSocketInfo>& socketInfos, std::unordered_map<net_addr_t, uint32_t>& ip2rank,
    std::vector<IpType>& types, std::unordered_set<uint32_t>& connectedRanks, uint32_t& successCount)
{
    for (auto i = 0U; i < getSize; i++) {
        if (socketInfos[i].status != 1) {
            continue;
        }
        net_addr_t addr;
        char ipStr[INET6_ADDRSTRLEN];
        char* result{};
        if (types[i] == IpV4) {
            addr.type = IpV4;
            addr.ip.ipv4 = socketInfos[i].remoteIp.addr;
            result = inet_ntoa(socketInfos[i].remoteIp.addr);
        } else if (types[i] == IpV6) {
            addr.type = IpV6;
            addr.ip.ipv6 = socketInfos[i].remoteIp.addr6;
            inet_ntop(AF_INET6, &socketInfos[i].remoteIp.addr6, ipStr, INET6_ADDRSTRLEN);
            result = ipStr;
        }
        auto pos = ip2rank.find(addr);
        if (pos == ip2rank.end()) {
            SHM_LOG_ERROR("get non-expected socket remote ip: " << result);
            continue;
        }
        auto rankId = pos->second;
        auto nPos = connections_.find(rankId);
        if (nPos == connections_.end()) {
            SHM_LOG_ERROR("get non-expected ip: " << result << ", rank: " << rankId);
            continue;
        }

        nPos->second.socketFd = socketInfos[i].fd;
        connectedRanks.emplace(pos->second);
        ip2rank.erase(pos);
        successCount++;
    }
}

int32_t DynamicRanksQpManager::GetSocketConn(
    std::vector<HccpSocketInfo>& socketInfos, QueryConnectionStateTask& currTask,
    std::unordered_map<net_addr_t, uint32_t>& ip2rank, std::unordered_set<uint32_t>& connectedRanks,
    std::vector<IpType>& types)
{
    uint32_t cnt = 0;
    uint32_t successCount = 0;
    uint32_t batchCnt = 16;
    do {
        auto socketRole = rankRole_ == hybm_role_type::HYBM_ROLE_SENDER ? 1 : 0;
        uint32_t getSize = socketInfos.size() < batchCnt ? socketInfos.size() : batchCnt;
        auto ret = DlHccpApi::RaGetSockets(socketRole, socketInfos.data(), getSize, cnt);
        if (ret != 0) {
            auto failedCount = currTask.Failed(ip2rank);
            SHM_LOG_ERROR(
                "socketRole(" << socketRole << ") side get sockets failed: " << ret << ", count: " << failedCount);
            return 1;
        }
        std::this_thread::sleep_for(std::chrono::seconds(1));
        if (cnt == 0) {
            continue;
        }
        ProcessSocketConnectionsByIP(getSize, socketInfos, ip2rank, types, connectedRanks, successCount);
        std::vector<HccpSocketInfo>::iterator it = socketInfos.begin();
        for (; it != socketInfos.end();) {
            if (it->status == 1) {
                it = socketInfos.erase(it);
            } else {
                it++;
            }
        }
    } while (socketInfos.size() > 0);
    return ACLSHMEM_SUCCESS;
}

int DynamicRanksQpManager::ProcessQueryConnectionStateTask() noexcept
{
    auto& currTask = connectionTasks_.queryConnectTask;
    if (!currTask.status.exist || currTask.ip2rank.empty()) {
        currTask.status.exist = false;
        return 0;
    }

    currTask.status.exist = false;
    auto ip2rank = std::move(currTask.ip2rank);
    if (currTask.status.failedTimes > 0L) {
        std::this_thread::sleep_for(std::chrono::seconds(delay));
    }

    std::vector<HccpSocketInfo> socketInfos;
    std::vector<IpType> types{};
    Parse2SocketInfo(ip2rank, socketInfos, types);

    std::unordered_set<uint32_t> connectedRanks;
    auto ret = GetSocketConn(socketInfos, currTask, ip2rank, connectedRanks, types);
    if (ret != 0) {
        return ret;
    }

    if (!ip2rank.empty()) {
        currTask.Failed(ip2rank);
    } else {
        currTask.status.failedTimes = 0;
    }

    auto& nextTask = connectionTasks_.connectQpTask;
    nextTask.ranks.insert(connectedRanks.begin(), connectedRanks.end());
    nextTask.status.exist = true;
    nextTask.status.failedTimes = 0;
    return !ip2rank.empty();
}

int DynamicRanksQpManager::ProcessConnectQpTask() noexcept
{
    auto& currTask = connectionTasks_.connectQpTask;
    if (!currTask.status.exist || currTask.ranks.empty()) {
        currTask.status.exist = false;
        return 0;
    }

    currTask.status.exist = false;
    auto ranks = std::move(currTask.ranks);
    if (currTask.status.failedTimes > 0L) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    int failedCount = 0;
    std::unordered_set<uint32_t> connectedQpRanks;
    for (auto rank : ranks) {
        auto pos = connections_.find(rank);
        if (pos == connections_.end()) {
            SHM_LOG_INFO("connection to " << rank << " not exist.");
            continue;
        }

        if (pos->second.qpHandle == nullptr) {
            auto ret = DlHccpApi::RaQpCreate(rdmaHandle_, 0, 2, pos->second.qpHandle);
            if (ret != 0) {
                auto times = currTask.Failed(ranks);
                SHM_LOG_ERROR("create QP to " << rank << " failed: " << ret << ", times: " << times);
                failedCount++;
                continue;
            }
            SHM_LOG_INFO("create QP to " << rank << " success, qpHandle=" << pos->second.qpHandle);
            pos->second.qpConnectCalled = false;
        }

        if (!pos->second.qpConnectCalled) {
            auto ret = DlHccpApi::RaQpConnectAsync(pos->second.qpHandle, pos->second.socketFd);
            if (ret != 0) {
                auto times = currTask.Failed(ranks);
                SHM_LOG_ERROR("create QP to " << rank << " failed: " << ret << ", times: " << times);
                failedCount++;
                continue;
            }
            pos->second.qpConnectCalled = true;
        }

        connectedQpRanks.emplace(rank);
    }

    auto& nextTask = connectionTasks_.queryQpStateTask;
    nextTask.ranks.insert(connectedQpRanks.begin(), connectedQpRanks.end());
    nextTask.status.exist = true;
    nextTask.status.failedTimes = 0;
    return failedCount > 0;
}

int DynamicRanksQpManager::ProcessQueryQpStateTask() noexcept
{
    auto& currTask = connectionTasks_.queryQpStateTask;
    if (!currTask.status.exist || currTask.ranks.empty()) {
        currTask.status.exist = false;
        return 0;
    }

    currTask.status.exist = false;
    auto ranks = std::move(currTask.ranks);
    if (currTask.status.failedTimes > 0L) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    auto localMrs = GenerateLocalLiteMrs();
    for (auto rank : ranks) {
        auto pos = connections_.find(rank);
        if (pos == connections_.end()) {
            SHM_LOG_INFO("connection to " << rank << " not exist.");
            continue;
        }

        auto ret = DlHccpApi::RaGetQpStatus(pos->second.qpHandle, pos->second.qpStatus);
        if (ret != 0) {
            auto times = currTask.Failed(ranks);
            SHM_LOG_ERROR("get QP status to " << rank << " failed: " << ret << ", fail times: " << times);
            currTask.ranks.emplace(rank);
            continue;
        }

        SHM_LOG_INFO("get QP status to " << rank << " success. qpStatus: " << pos->second.qpStatus);
        if (pos->second.qpStatus != 1) {
            currTask.ranks.emplace(rank);
            continue;
        }
        auto remoteMrs = GenerateRemoteLiteMrs(rank);
        SetQpHandleRegisterMr(pos->second.qpHandle, localMrs, true);
        SetQpHandleRegisterMr(pos->second.qpHandle, remoteMrs, false);
    }

    if (!currTask.ranks.empty()) {
        currTask.status.exist = true;
        currTask.status.failedTimes++;
        return 1;
    }

    return 0;
}

void DynamicRanksQpManager::ProcessUpdateLocalMrTask() noexcept
{
    auto& currTask = connectionTasks_.updateMrTask;
    std::unique_lock<std::mutex> uniqueLock{currTask.locker};
    if (!currTask.status.exist) {
        return;
    }
    currTask.status.exist = false;
    uniqueLock.unlock();

    auto localMRs = GenerateLocalLiteMrs();
    for (auto it = connections_.begin(); it != connections_.end(); ++it) {
        if (it->second.qpHandle == nullptr || it->second.qpStatus != 1) {
            continue;
        }
        SetQpHandleRegisterMr(it->second.qpHandle, localMRs, true);
    }
}

void DynamicRanksQpManager::ProcessUpdateRemoteMrTask() noexcept
{
    auto& currTask = connectionTasks_.updateRemoteMrTask;
    std::unique_lock<std::mutex> uniqueLock{currTask.locker};
    if (!currTask.status.exist) {
        return;
    }
    currTask.status.exist = false;
    auto addedMrRanks = std::move(currTask.addedMrRanks);
    uniqueLock.unlock();
    for (auto remoteRank : addedMrRanks) {
        auto mrs = GenerateRemoteLiteMrs(remoteRank);
        auto pos = connections_.find(remoteRank);
        if (pos == connections_.end()) {
            continue;
        }

        SetQpHandleRegisterMr(pos->second.qpHandle, mrs, false);
    }
}

void DynamicRanksQpManager::CloseServices() noexcept
{
    if (backGroundThread_ != nullptr) {
        managerRunning_.store(false);
        cond_.notify_one();
        backGroundThread_->join();
        backGroundThread_ = nullptr;
    }

    std::vector<HccpSocketCloseInfo> socketCloseInfos;
    for (auto it = connections_.begin(); it != connections_.end(); ++it) {
        if (it->second.qpHandle != nullptr) {
            auto ret = DlHccpApi::RaQpDestroy(it->second.qpHandle);
            if (ret != 0) {
                SHM_LOG_WARN("destroy QP to server: " << it->first << " failed: " << ret);
            }
            it->second.qpHandle = nullptr;
        }

        if (it->second.socketFd != nullptr) {
            HccpSocketCloseInfo info;
            info.handle = it->second.socketHandle;
            info.fd = it->second.socketFd;
            info.linger = 0;
            socketCloseInfos.push_back(info);
            it->second.socketFd = nullptr;
        }
    }

    auto ret = DlHccpApi::RaSocketBatchClose(socketCloseInfos.data(), socketCloseInfos.size());
    if (ret != 0) {
        SHM_LOG_INFO("close sockets return: " << ret);
    }

    for (auto it = connections_.begin(); it != connections_.end(); ++it) {
        ret = DlHccpApi::RaSocketDeinit(it->second.socketHandle);
        if (ret != 0) {
            SHM_LOG_INFO("deinit socket to server: " << it->first << " return: " << ret);
        }
    }

    for (auto& conn : connectionView_) {
        conn = nullptr;
    }
    connections_.clear();
    DestroyServerSocket();
}

std::vector<lite_mr_info> DynamicRanksQpManager::GenerateLocalLiteMrs() noexcept
{
    std::vector<lite_mr_info> localMrs;
    std::unique_lock<std::mutex> uniqueLock{mutex_};
    for (auto it = currentLocalMrs_.begin(); it != currentLocalMrs_.end(); ++it) {
        lite_mr_info info;
        info.key = it->second.lkey;
        info.addr = it->second.address;
        info.len = it->second.size;
        localMrs.emplace_back(info);
    }
    uniqueLock.unlock();
    return localMrs;
}

std::vector<lite_mr_info> DynamicRanksQpManager::GenerateRemoteLiteMrs(uint32_t rankId) noexcept
{
    std::vector<lite_mr_info> remoteMrs;
    std::unique_lock<std::mutex> uniqueLock{mutex_};
    auto pos = currentRanksInfo_.find(rankId);
    if (pos == currentRanksInfo_.end()) {
        uniqueLock.unlock();
        return remoteMrs;
    }

    for (auto it = pos->second.memoryMap.begin(); it != pos->second.memoryMap.end(); ++it) {
        lite_mr_info info;
        info.key = it->second.lkey;
        info.addr = it->second.address;
        info.len = it->second.size;
        remoteMrs.emplace_back(info);
    }
    uniqueLock.unlock();
    return remoteMrs;
}

bool DynamicRanksQpManager::HasNewMemoryRegion(
    const MemoryRegionMap& currentMemoryMap, const MemoryRegionMap& lastMemoryMap) noexcept
{
    for (const auto& mit : currentMemoryMap) {
        if (lastMemoryMap.find(mit.first) == lastMemoryMap.end()) {
            return true;
        }
    }
    return false;
}

void DynamicRanksQpManager::GenDiffInfoChangeRanks(
    const std::unordered_map<uint32_t, ConnectRankInfo>& last, std::unordered_map<uint32_t, mf_sockaddr>& addedRanks,
    std::unordered_set<uint32_t>& addMrRanks) noexcept
{
    for (auto it = currentRanksInfo_.begin(); it != currentRanksInfo_.end(); ++it) {
        auto pos = last.find(it->first);
        if (pos == last.end()) {
            addedRanks.emplace(it->first, it->second.network);
        } else if (HasNewMemoryRegion(it->second.memoryMap, pos->second.memoryMap)) {
            addMrRanks.emplace(it->first);
        }
    }
}

void DynamicRanksQpManager::GenTaskFromChangeRanks(
    const std::unordered_map<uint32_t, mf_sockaddr>& addedRanks,
    const std::unordered_set<uint32_t>& addMrRanks) noexcept
{
    if (rankRole_ == hybm_role_type::HYBM_ROLE_RECEIVER) {
        auto& task = connectionTasks_.whitelistTask;
        std::unique_lock<std::mutex> taskLocker{task.locker};
        for (auto it = addedRanks.begin(); it != addedRanks.end(); ++it) {
            net_addr_t addr;
            if (it->second.type == IpV4) {
                addr.type = IpV4;
                addr.ip.ipv4 = it->second.ip.ipv4.sin_addr;
            } else if (it->second.type == IpV6) {
                addr.type = IpV6;
                addr.ip.ipv6 = it->second.ip.ipv6.sin6_addr;
            }
            task.remoteIps.emplace(it->first, addr);
        }
        task.status.exist = !task.remoteIps.empty();
        task.status.failedTimes = 0;
    } else {
        auto& task = connectionTasks_.clientConnectTask;
        std::unique_lock<std::mutex> taskLocker{task.locker};
        for (auto it = addedRanks.begin(); it != addedRanks.end(); ++it) {
            task.remoteAddress.emplace(it->first, it->second);
        }
        task.status.exist = !task.remoteAddress.empty();
        task.status.failedTimes = 0;
    }

    auto& task = connectionTasks_.updateRemoteMrTask;
    std::unique_lock<std::mutex> taskLocker{task.locker};
    task.addedMrRanks.insert(addMrRanks.begin(), addMrRanks.end());
    task.status.exist = !task.addedMrRanks.empty();
    task.status.failedTimes = 0;
    taskLocker.unlock();

    if (addedRanks.empty() && addMrRanks.empty()) {
        return;
    }

    cond_.notify_one();
}

void DynamicRanksQpManager::SetQpHandleRegisterMr(
    void* qpHandle, const std::vector<lite_mr_info>& mrs, bool local) noexcept
{
    if (qpHandle == nullptr) {
        return;
    }

    auto qp = (ra_qp_handle*)qpHandle;
    auto dest = local ? qp->local_mr : qp->rem_mr;
    pthread_mutex_lock(&qp->qp_mutex);
    for (auto i = 0U; i < mrs.size() && i < RA_MR_MAX_NUM - 1U; i++) {
        dest[i + 1] = mrs[i];
    }
    pthread_mutex_unlock(&qp->qp_mutex);
}
} // namespace device
} // namespace transport
} // namespace shm
