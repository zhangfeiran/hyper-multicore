/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef MEM_FABRIC_HYBRID_HYBM_EX_INFO_TRANSFER_H
#define MEM_FABRIC_HYBRID_HYBM_EX_INFO_TRANSFER_H

#include <cstring>
#include <string>
#include <type_traits>
#include <algorithm>
#include "hybm_def.h"
#include "shmemi_logger.h"

namespace shm {
template <class DataType> class ExInfoTranslator {
public:
    virtual int Serialize(const DataType &d, std::string &info) noexcept = 0;
    virtual int Deserialize(const std::string &info, DataType &d) noexcept = 0;
};

template <class DataType> class LiteralExInfoTranslater : public ExInfoTranslator<DataType> {
public:
    int Serialize(const DataType &d, std::string &info) noexcept override
    {
        if (!std::is_trivially_copyable<DataType>::value) {
            return -1;
        }

        SHM_LOG_DEBUG("serialize data length = " << sizeof(DataType));
        info = std::string(reinterpret_cast<const char *>(&d), sizeof(DataType));
        return 0;
    }

    int Deserialize(const std::string &info, DataType &d) noexcept override
    {
        if (!std::is_trivially_copyable<DataType>::value) {
            return -1;
        }

        if (info.length() != sizeof(DataType)) {
            SHM_LOG_ERROR("deserialize info len: " << info.length() << " not matches data type: " << sizeof(DataType));
            return -1;
        }

        std::copy_n(info.data(), sizeof(DataType), reinterpret_cast<uint8_t *>(&d));
        return 0;
    }
};

class ExchangeInfoReader {
public:
    explicit ExchangeInfoReader(const hybm_exchange_info *info = nullptr) noexcept : exchangeInfo_{info}, readOffset_{0}
    {
    }

    void Reset(const hybm_exchange_info *info = nullptr) noexcept
    {
        if (info != nullptr) {
            exchangeInfo_ = info;
        }
        readOffset_ = 0;
    }

    inline int Test(void *buffer, size_t length) const noexcept
    {
        SHM_ASSERT_RETURN(exchangeInfo_ != nullptr, -1);
        if (readOffset_ + length > exchangeInfo_->descLen) {
            SHM_LOG_ERROR("read data size: " << length << " too long");
            return -1;
        }

        try {
            std::copy_n(exchangeInfo_->desc + readOffset_, length, (uint8_t *)buffer);
        } catch (...) {
            SHM_LOG_ERROR("copy failed.");
            return -1;
        }
        return 0;
    }

    inline int Read(void *buffer, size_t length) const noexcept
    {
        SHM_ASSERT_RETURN(exchangeInfo_ != nullptr, -1);
        if (readOffset_ + length > exchangeInfo_->descLen) {
            SHM_LOG_ERROR("read data size: " << length << " too long");
            return -1;
        }

        try {
            std::copy_n(exchangeInfo_->desc + readOffset_, length, (uint8_t *)buffer);
        } catch (...) {
            SHM_LOG_ERROR("copy failed.");
            return -1;
        }
        readOffset_ += length;
        return 0;
    }

    inline size_t LeftBytes() const noexcept
    {
        SHM_ASSERT_RETURN(exchangeInfo_ != nullptr, 0);
        if (readOffset_ >= exchangeInfo_->descLen) {
            return 0U;
        }

        return exchangeInfo_->descLen - readOffset_;
    }

    std::string LeftToString() const noexcept
    {
        SHM_ASSERT_RETURN(exchangeInfo_ != nullptr, "");
        if (readOffset_ >= exchangeInfo_->descLen) {
            return "";
        }

        std::string left(exchangeInfo_->desc + readOffset_, exchangeInfo_->desc + exchangeInfo_->descLen);
        readOffset_ = exchangeInfo_->descLen;
        return left;
    }

    template <typename DataType>
    inline int Test(DataType &data) const noexcept
    {
        return Test(static_cast<void *>(&data), sizeof(data));
    }

    template <typename DataType>
    inline int Read(DataType &data) const noexcept
    {
        return Read(static_cast<void *>(&data), sizeof(data));
    }

private:
    const hybm_exchange_info *exchangeInfo_;
    mutable uint32_t readOffset_;
};

class ExchangeInfoWriter {
public:
    explicit ExchangeInfoWriter(hybm_exchange_info *info) noexcept : exchangeInfo_{info}
    {
        if (exchangeInfo_ != nullptr) {
            exchangeInfo_->descLen = 0;
        }
    }

    inline int Append(const void *data, size_t length) noexcept
    {
        SHM_ASSERT_RETURN(exchangeInfo_ != nullptr, -1);
        if (exchangeInfo_->descLen + length > sizeof(exchangeInfo_->desc)) {
            SHM_LOG_ERROR("append " << length << " bytes overflows desc(used=" << exchangeInfo_->descLen
                << ", capacity=" << sizeof(exchangeInfo_->desc) << ")");
            return -1;
        }

        try {
            std::copy_n(reinterpret_cast<const uint8_t *>(data), length, exchangeInfo_->desc + exchangeInfo_->descLen);
        } catch (...) {
            SHM_LOG_ERROR("copy failed.");
            return -1;
        }
        exchangeInfo_->descLen += length;
        return 0;
    }

    template <class DataType>
    inline int Append(const DataType &data) noexcept
    {
        return Append(reinterpret_cast<const void *>(&data), sizeof(data));
    }

private:
    hybm_exchange_info *exchangeInfo_;
};
}
#endif // MEM_FABRIC_HYBRID_HYBM_EX_INFO_TRANSFER_H
